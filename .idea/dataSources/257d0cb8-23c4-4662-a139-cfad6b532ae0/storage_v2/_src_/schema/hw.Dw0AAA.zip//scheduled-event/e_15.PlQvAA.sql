create definer = root@localhost event e_15
  on schedule
    at '2018-12-21 00:00:00'
  enable
do
  update userorder set valid = 0 where oid = 15;

