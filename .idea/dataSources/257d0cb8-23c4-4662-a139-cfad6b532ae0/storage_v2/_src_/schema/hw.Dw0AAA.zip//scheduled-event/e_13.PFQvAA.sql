create definer = root@localhost event e_13
  on schedule
    at '2018-11-30 00:00:00'
  enable
do
  update userorder set valid = 0 where oid = 13;

